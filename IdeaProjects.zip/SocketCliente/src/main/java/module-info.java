module com.example.socketcliente {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.socketcliente to javafx.fxml;
    exports com.example.socketcliente;
}