package com.example.socketcliente;

public class Cliente {
}
