module com.example.socketservidor {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.socketservidor to javafx.fxml;
    exports com.example.socketservidor;
}