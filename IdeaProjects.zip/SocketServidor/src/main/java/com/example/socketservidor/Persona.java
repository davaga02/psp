package com.example.socketservidor;

import java.io.Serializable;

public class Persona implements Serializable {
}
