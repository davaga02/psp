package com.example.socketservidor;

public class Servidor {
}
