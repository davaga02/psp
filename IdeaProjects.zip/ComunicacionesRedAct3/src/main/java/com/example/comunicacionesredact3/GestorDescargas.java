package com.example.comunicacionesredact3;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;

public class GestorDescargas {

    public void descargarArchivo(String url_descargar,String nombreArchivo){

        System.out.println("Descargando" + url_descargar);
        try {

            URL laUrl=new URL(url_descargar);

            InputStream is= laUrl.openStream();
            FileOutputStream fos = new FileOutputStream(nombreArchivo);

            byte[] buffer = new byte[8192];
            int bytes;

            while ((bytes = is.read(buffer)) != -1){

                fos.write(buffer, 0, bytes);

            }


            is.close();
            fos.close();

        } catch (MalformedURLException e) {
            System.out.println("URL mal escrita!");
        } catch (IOException e) {
            System.out.println("Fallo en la lectura del fichero");
        }
    }
}
