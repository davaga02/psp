package com.dam.daniela;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class Conexion {
	
	private Connection con;
	
	public ArrayList<Persona> obtenerUsuarios() {
		
		ArrayList<Persona> p = new ArrayList<>();
		

		try {
			
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/libreria","root","");
			Statement stm = con.createStatement();
			ResultSet rs = stm.executeQuery("SELECT * FROM usuarios");
			
			while(rs.next()) {
				p.add(new Persona(rs.getInt(1), rs.getString(2), rs.getString(3)));
			}
			
			rs.close();
			stm.close();
			con.close();
			
			
		}catch(Exception e){
			e.printStackTrace();
		
		}
		
		return p;

	}
}
