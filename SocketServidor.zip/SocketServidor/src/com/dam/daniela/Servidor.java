package com.dam.daniela;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

public class Servidor {
	
	public static void main(String[] args) throws IOException, ClassNotFoundException {
		
		 
		int numeroPuerto = 6000;
		
		ServerSocket servidor = new ServerSocket(numeroPuerto);
		System.err.println("SERVIDOR >> Escuchando...");
		
		Socket cliente = servidor.accept(); //Espera la conexión de un cliente
		
		ObjectOutputStream outObjeto = new ObjectOutputStream(cliente.getOutputStream());
		Persona p = new Persona(0, "Nombre", "0"); //Se le pasa objeto al cliente
		outObjeto.writeObject(p);
		
		System.err.println("SERVIDOR >> Envío al cliente: " + p.getNombre() + " " + p.getContrasenya());
		
		ObjectInputStream inObjeto = new ObjectInputStream(cliente.getInputStream());
		Persona pMod = (Persona) inObjeto.readObject();
		
		System.err.println("SERVIDOR >> Recibo de cliente:" + pMod.getNombre() + " " + pMod.getContrasenya());
		
		boolean entrar = logIn(pMod.getNombre(), pMod.getContrasenya());
		
		if(entrar == true) {
			
			System.out.println("Entra");
			
		}else {
			
			System.out.println("No entra");
			
		}
		
		
	
		outObjeto.close();
		inObjeto.close();
		cliente.close();
		servidor.close();

	}
	
	public static boolean logIn(String nombre, String contrasenya) {
		
		Conexion con = new Conexion();
		ArrayList<Persona> pers;
		
		boolean respuesta = false;
		
		if(!nombre.isEmpty() && !contrasenya.isEmpty()) {
			
			pers = con.obtenerUsuarios();
			
			for(Persona persona: pers) {
				
				if(persona.getNombre().equals(nombre) && persona.getContrasenya().equals(contrasenya)) {
					
					respuesta = true;
				}
			}
			
		}
		
		return respuesta;
	}

}
