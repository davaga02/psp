package com.dam.daniela;

import java.io.Serializable;

public class Persona implements Serializable {
	
	int id;
	String nombre;
	String contrasenya;
	
	public Persona(int id, String nombre, String contrasenya) {
		super();
		this.id = id;
		this.nombre = nombre;
		this.contrasenya = contrasenya;
		
	}
	public Persona() {
		
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getContrasenya() {
		return contrasenya;
	}
	public void setContrasenya(String contrasenya) {
		this.contrasenya = contrasenya;
	}
	
	
	

	
	

}
