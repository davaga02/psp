/**
 * 
 */
/**
 * 
 */
module SocketServidor {
	requires java.sql;
}