package com.dam.daniela;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Cliente {

	public static void main(String[] args) throws UnknownHostException, IOException, ClassNotFoundException {
		
		Scanner teclado = new Scanner(System.in);
		String host = "localhost";
		int puerto = 6000;
		System.out.println("CLIENTE >> Arranca cliente");
		
		Socket cliente = new Socket(host, puerto);
		
		ObjectInputStream inObjeto = new ObjectInputStream(cliente.getInputStream());
		Persona p = (Persona) inObjeto.readObject();
		
		System.out.println("CLIENTE >> Recibo del servidor: "+p.getNombre() + " - " + p.getContrasenya());
		
		System.out.println("LOG IN");
		System.out.println("Dime el nombre: ");
		String nombre = teclado.next();
		System.out.println("Dime la contraseña: ");
		String contrasenya = teclado.next();
		
		p.setNombre(nombre);
		p.setContrasenya(contrasenya);
		
		ObjectOutputStream pMod = new ObjectOutputStream(cliente.getOutputStream());
		pMod.writeObject(p);
		
		System.out.println("CLIENTE >> Envio al servidor: "+p.getNombre() + " - " + p.getContrasenya());
		inObjeto.close();
		pMod.close();
		cliente.close();


	}

}
