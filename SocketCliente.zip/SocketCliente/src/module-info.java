/**
 * 
 */
/**
 * 
 */
module SocketCliente {
}